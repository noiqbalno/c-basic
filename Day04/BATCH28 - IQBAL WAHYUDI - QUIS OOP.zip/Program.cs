﻿using Day04.PartOne;
using Day04.PartThree;
using Day04.Quis;
//using Day04.PartTwo;

namespace Day04
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            

            //CALL QUIS INTERFACE
            IVehicle vehicle = new VehicleImpl();
            
            var listVehicle = vehicle.InitListVehicle();
            vehicle.DisplayVehicle(listVehicle);

            Console.WriteLine();
            Console.WriteLine($"Total Vehicle: {vehicle.GetTotalVehicle(listVehicle)}");
            Console.WriteLine($"Total Vehicle SUV: {vehicle.GetTotalVehicle(listVehicle, "SUV")}");
            Console.WriteLine($"Total Vehicle Taxi: {vehicle.GetTotalVehicle(listVehicle, "Taxi")}");
            Console.WriteLine($"Total Vehicle PrivateJet: {vehicle.GetTotalVehicle(listVehicle, "PrivateJet")}");
            Console.WriteLine();
            Console.WriteLine($"Sub Total SUV: {vehicle.GetSubTotal(listVehicle, "SUV")}");
            Console.WriteLine($"Sub Total Taxi: {vehicle.GetSubTotal(listVehicle, "Taxi")}");
            Console.WriteLine($"Sub Total PrivateJet: {vehicle.GetSubTotal(listVehicle, "PrivateJet")}");
            Console.WriteLine($"Sub Total: {vehicle.GetSubTotal(listVehicle)}");
        }
    }
}